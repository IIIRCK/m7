<?php
include ('./cnx.php');
//select('persona');
//delete('persona',2);
select('persona');
//insert("p1","c1","p1@gmail.com","123456789");
