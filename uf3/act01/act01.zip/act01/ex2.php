
<?php
include ('./cnx.php');
include ('./fun.php');
?>
<form method="post">
    <label for="name">name</>
    <input type="text" name="name">
    <label for="surname">surname</>
    <input type="text" name="surname">
    <label for="email">email</>
    <input type="text" name="email">
    <label for="telf">telf</>
    <input type="text" name="telf">
    <input type="submit" name="ok" >
</form>
<br>
<?php
select('persona');
?>